#include <stdio.h>

int main(void) {
    printf("I love MIPS\n");
    return 0;
}
