// add 17 and 25  and print result

#include <stdio.h>

int main(void) {
    int x = 17;
    int y = 25;
    printf("%d\n", x + y);

    return 0;
}
